---
pageTitle: New Felijity website!
pageTemplate: templates/pages/home.html
---

# Hi there, this is a brand new Felijity website!

If you read this content, it means you succesfully created a new website and
launched:  

> felijity serve
 
It worked like a charm, you did a very good job: **Compliments!**

## Now what?

Well, now it's time to make changes to transorm this site in your own site,
replacing the content you see now with your own.  
How to do it? Well, first have a look at the varius pages that are now up &
running browsing this website, reading documentation, and so on. Then look in
the main source directory for this website and you'll see where every pages came
from.  
For example the content of this page is in the file:
  
> &lt;website-root-folder&gt;/pages/index.md

Now if you want to create a new page at the url:
   
> http:&#47;&#47;&lt;my-truly-mine-website&gt;/this-is-a-brand-new-page-of-mine

Just create the file

> &lt;website-root-folder&gt;/pages/this-is-a-brand-new-page-of-mine.md

et voilà, that's it!  

For more options, info and tutorials click 
[Resources](/documentation) and [Documentation](/documentation/) on the top menu.

### Now go, enjoy Felijity and if you think we deserve it, [support us](https://ansorre.github.io/support) to help expand, mantain and grow its development! 

Remember this is open source software, it can exists only thanks to your support.  


     
